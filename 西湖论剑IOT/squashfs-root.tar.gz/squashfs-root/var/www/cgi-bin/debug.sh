#!/bin/bash
export HTTP_COOKIES=uuid=aaaabbbbccccdddd
export REQUEST_METHOD=POST
export CONTENT_TYPE=application/x-www-form-urlencoded
export CONTENT_LENGTH=1452
