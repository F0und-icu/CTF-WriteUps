#!/bin/sh


while true;
do
    /home/ctf/qemu-mipsel-static -L /home/ctf/ /home/ctf/lighttpd -f /etc/lighttpd/lighttpd.conf
    sleep 5
done
# sleep infinity;
