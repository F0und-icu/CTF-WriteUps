#!/bin/sh
CMD="./qemu-mipsel-static"
ARGS="-g 1234 -L ./ ./server/sbin/lighttpd -m ./server/lib -f ./rhttpd/lighttpd/lighttpd.conf"
START_CMD="$CMD $ARGS"

while true; do
  if ! pgrep -f "$CMD $ARGS" > /dev/null; then
    echo "Process not found. Restarting..."
    # 重启进程
    cd /home/ctf &&  rm /*.core
    su ctf -c './qemu-mipsel-static -g 1234 -L ./ ./server/sbin/lighttpd -m ./server/lib -f ./rhttpd/lighttpd/lighttpd.conf'
  fi
  sleep 1
done

